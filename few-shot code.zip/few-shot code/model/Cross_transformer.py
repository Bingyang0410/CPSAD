import torch
from torch import nn
import torch.nn.functional as F

class CF(nn.Module):
    def __init__(self ,dim = 256):
        super(CF, self).__init__()

        self.dim = dim

        self.k = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0)
        self.q = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0)
        self.v = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0)

    def forward(self, x1, x2):

        batch_size = x1.size(0)

        k = self.k(x1).view(batch_size, self.dim, -1)
        k = k.permute(0, 2, 1)

        q = self.q(x2).view(batch_size, self.dim, -1)

        v = self.v(x1).view(batch_size, self.dim, -1)
        vt = v.permute(0, 2, 1)

        kq_matmul = torch.matmul(k, q)
        kq_matmul = F.softmax(kq_matmul, dim=-1)

        kqv_matmul = torch.matmul(kq_matmul, vt)

        y = kqv_matmul.permute(0, 2, 1)
        y = y.view(batch_size, self.dim, *x1.size()[2:])
        y = y + x1

        return y