import torch
from torch import nn
import torch.nn.functional as F
from model.widgets.ASPP import ASPP


class SubNet(nn.Module):
    def __init__(self, dim=256):
        super(SubNet, self).__init__()

        self.con1x1_down = nn.Conv2d(dim*6, dim, kernel_size=1)
        self.con1x1_same = nn.Conv2d(dim, dim, kernel_size=1)

        self.DM_Attentionx6 = DM_Attentionx5(256)

        self.DM_Attentionx1 = DM_Attentionx1(256)

        self.ASPP = ASPP()

    def forward(self,supp_feat1_out,supp_feat2_out,query_feat1_out,query_feat2_out,norm_feat_out):

        supp_feat = torch.cat([supp_feat1_out,supp_feat2_out],dim = 1)

        query_feat = torch.cat([query_feat1_out,query_feat2_out],dim = 1)

        feat_sum1 = torch.cat([supp_feat,query_feat],dim = 1)

        feat_sum = torch.cat([feat_sum1,norm_feat_out],dim = 1)

        feat_out = self.DM_Attentionx6(feat_sum,feat_sum1)

        feat_out = self.ASPP(feat_out)

        feat_out = self.DM_Attentionx1(feat_out,feat_sum)

        return feat_out


class DM_Attentionx5(nn.Module):
    def __init__(self, dim ):
        super(DM_Attentionx5, self).__init__()

        self.con1x1_down1 = nn.Conv2d(dim*4, dim, kernel_size=1)
        self.con1x1_down2 = nn.Conv2d(dim * 5, dim, kernel_size=1)
        self.con1x1_same = nn.Conv2d(dim, dim, kernel_size=1)
        self.sigmod = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(dim)
        self.gap = nn.AdaptiveAvgPool2d(1)

    def forward(self,x,y):

        y_d = self.con1x1_down1(y)
        y = self.gap(y_d)
        y = self.con1x1_same(y)
        y = self.sigmod(y)
        y = y
        x= self.con1x1_down2(x)
        z = x * y

        out = self.con1x1_same(z)

        return out

class DM_Attentionx1(nn.Module):
    def __init__(self, dim):
        super(DM_Attentionx1, self).__init__()

        self.con1x1_same = nn.Conv2d(dim, dim, kernel_size=1)
        self.con1x1_down = nn.Conv2d(dim * 5, dim, kernel_size=1)
        self.sigmod = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(dim)
        self.gap = nn.AdaptiveAvgPool2d(1)

    def forward(self, x, y):

        y_d = self.con1x1_down(y)
        y = self.gap(y_d)
        y = self.con1x1_same(y)
        y = self.sigmod(y)
        y = y
        z = x * y

        out = self.con1x1_same(z)

        return out

class DM_Attentionx1_v2(nn.Module):
    def __init__(self, dim):
        super(DM_Attentionx1_v2, self).__init__()

        self.con1x1_same = nn.Conv2d(dim, dim, kernel_size=1)
        self.con1x1_down = nn.Conv2d(dim * 3, dim, kernel_size=1)
        self.sigmod = nn.Sigmoid()
        self.bn = nn.BatchNorm2d(dim)
        self.gap = nn.AdaptiveAvgPool2d(1)

    def forward(self, x, y):

        y_d = self.con1x1_down(y)
        y = self.gap(y_d)
        y = self.con1x1_same(y)
        y = self.sigmod(y)
        y = y
        z = x * y

        out = self.con1x1_same(z)

        return out

class CS_feat(nn.Module):
    def __init__(self, dim, extend_size):
        super(CS_feat, self).__init__()

        self.Conv_up = nn.Conv2d(dim,extend_size,kernel_size=1)
        self.Conv_down = nn.Conv2d(extend_size, dim, kernel_size=1)
        self.Conv_same1 = nn.Conv2d(dim,dim,kernel_size=1)
        self.Conv_same2 = nn.Conv2d(extend_size,extend_size,kernel_size=1)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.sigmod = nn.Sigmoid()

    def forward(self, x):

        x_size = x.size()
        x_h, x_w = x_size[2], x_size[3]

        x_up = self.Conv_up(x)
        #x_up = self.sigmod(x_up)
        x_up = F.interpolate(x_up, size=(1,1),mode='bilinear',
                             align_corners=True)
        x_up = F.interpolate(x_up, size=(x_h, x_w), mode='bilinear',
                             align_corners=True)
        x_up = self.Conv_same2(x_up)
        #x_up = self.sigmod(x_up)
        x_up = self.Conv_down(x_up)

        x_same = x
        x_same = self.Conv_same1(x_same)
       # x_same = self.sigmod(x_same)

        out = x_up + x_same + x

        return out

class Multi_feat(nn.Module):
    def __init__(self, dim):
        super(Multi_feat, self).__init__()

        self.Conv_down1 = nn.Conv2d(dim, int(dim/2), kernel_size=1)
        self.Conv_up1 = nn.Conv2d(int(dim/2), dim, kernel_size=1)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.Conv_same1 = nn.Conv2d(dim, dim, kernel_size=1)
        self.Conv_same2 = nn.Conv2d(int(dim/2), int(dim/2), kernel_size=1)
        self.sigmod = nn.Sigmoid()

    def forward(self,x):

        x_size = x.size()
        x_h, x_w = x_size[2], x_size[3]

        x_1 = x
        x_1 = self.Conv_down1(x_1)
        x_1_gap = self.gap(x_1)
        x_1_downsize = F.interpolate(x_1, size=(1, 1), mode='bilinear',
                             align_corners=True)
        x_1_1 = x_1 * x_1_gap
        x_1_1 = self.Conv_up1(x_1_1)
        x_1_2 = x_1 * x_1_downsize
        x_1_2 = self.Conv_up1(x_1_2)
        x_1 = x_1_1 + x_1_2

        x_2 = x
        x_2 = F.interpolate(x_2, size=(int(x_h/2), int(x_w/2)), mode='bilinear',
                             align_corners=True)
        x_2 = self.Conv_down1(x_2)
        x_2_gap = self.gap(x_2)
        x_2_downsize = F.interpolate(x_2, size=(1, 1), mode='bilinear',
                                     align_corners=True)
        x_2_1 = x_2 * x_2_gap
        x_2_1 = self.Conv_up1(x_2_1)
        x_2_1 = F.interpolate(x_2_1, size=(x_h, x_w), mode='bilinear',
                             align_corners=True)
        x_2_2 = x_2 * x_2_downsize
        x_2_2 = self.Conv_up1(x_2_2)
        x_2_2 = F.interpolate(x_2_2, size=(x_h, x_w), mode='bilinear',
                              align_corners=True)
        x_2 = x_2_1 + x_2_2

        x_3 = x
        x_3 = F.interpolate(x_3, size=(x_h*2, x_w*2), mode='bilinear',
                            align_corners=True)
        x_3 = self.Conv_down1(x_3)
        x_3_gap = self.gap(x_3)
        x_3_downsize = F.interpolate(x_3, size=(1, 1), mode='bilinear',
                                     align_corners=True)
        x_3_1 = x_3 * x_3_gap
        x_3_1 = self.Conv_up1(x_3_1)
        x_3_1 = F.interpolate(x_3_1, size=(x_h, x_w), mode='bilinear',
                              align_corners=True)
        x_3_2 = x_3 * x_3_downsize
        x_3_2 = self.Conv_up1(x_3_2)
        x_3_2 = F.interpolate(x_3_2, size=(x_h, x_w), mode='bilinear',
                              align_corners=True)
        x_3 = x_3_1 + x_3_2

        out = x + x_1 + x_2 + x_3

        return out

