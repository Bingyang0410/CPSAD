import torch
from torch import nn
import torch.nn.functional as F
from model.widgets.ASPP import ASPP

class TB(nn.Module):
    def __init__(self, dim=256):
        super(TB, self).__init__()

        self.conv2t1 = nn.Conv2d(dim * 2, dim, kernel_size=1, stride=1, padding=0)
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.ASPP = ASPP()

    def forward(self, x1, x2):

        x1_gap = self.gap(x1)
        x2_gap = self.gap(x2)

        x_cat = torch.cat([x1, x2], dim=1)
        x_cat2norm = self.conv2t1(x_cat)

        x_product1 = x_cat2norm * x1_gap
        x_product2 = x_product1 * x2_gap

        out = self.ASPP(x_product2)

        return out