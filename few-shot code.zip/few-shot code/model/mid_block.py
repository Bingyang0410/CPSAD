import torch
from torch import nn
import torch.nn.functional as F

class DNF(nn.Module):
    def __init__(self, dim = 256):
        super(DNF, self).__init__()

        self.gap = nn.AdaptiveAvgPool2d(1)
        self.sigmod = nn.Sigmoid()
        self.conv2t1 = nn.Conv2d(dim*2, dim, kernel_size=1, stride=1, padding=0)
        self.conv1t1 = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        x_size = x.size()
        x_h, x_w = x_size[2], x_size[3]

        x_mid = x
        x_low = F.interpolate(x, size=(int(x_h/2), int(x_h/2)), mode='bilinear',
                             align_corners=True)

        x_low_gap = self.gap(x_low)
        x_low_gap_s = self.sigmod(x_low_gap)
        x_low = x_low * x_low_gap_s

        x_low2mid = F.interpolate(x_low, size=(x_h, x_h), mode='bilinear',
                             align_corners=True)

        x_mid = x_mid * x_low_gap
        x_mid_gap = self.gap(x_mid)
        x_mid_gap_s = self.sigmod(x_mid_gap)
        x_mid = x_mid * x_mid_gap_s

        out = torch.cat([x_low2mid, x_mid], dim=1)
        out = self.conv2t1(out)
        out = self.conv1t1(out)

        return out


class MB(nn.Module):
    def __init__(self, dim = 256):
        super(MB, self).__init__()

        self.conv1t1 = nn.Conv2d(dim, dim, kernel_size=1, stride=1, padding=0)
        self.conv2t1 = nn.Conv2d(dim * 2, dim, kernel_size=1, stride=1, padding=0)
        self.conv3t1 = nn.Conv2d(dim*3, dim, kernel_size=1, stride=1, padding=0)

        self.dnf1 = DNF(dim)
        self.dnf2 = DNF(dim*2)

    def forward(self, x1, x2):

        x1_conv = self.conv1t1(x1)
        x1_dnf = self.dnf1(x1_conv)

        x2_cat = torch.cat([x1_conv, x2], dim=1)
        x2_dnf = self.dnf2(x2_cat)

        out1 = torch.cat([x1_dnf, x2_dnf], dim=1)
        out1 = self.conv3t1(out1)
        out1 = out1 + x1

        out2 = self.conv2t1(x2_dnf)
        out2 = out2 + x2

        return out1, out2